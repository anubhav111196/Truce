Install angular CLIs:
1.Open CMD
2.Goto app>app>client
3. npm install

Install Package.Json:
1.Open CMD
2. Goto app>app>server
3.npm install

And you're good to go!